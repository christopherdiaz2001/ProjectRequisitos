package votacion.modelo;

/**
 *
 * @author
 */
public class Votacion extends Modelo {
    private ListaElectoral lista;
    private Usuario usuario;
    
    public Votacion(ListaElectoral lista, Usuario usuario) {
        this.lista = lista;
        this.usuario = usuario;
    }

    public ListaElectoral getLista() {
        return lista;
    }

    public void setLista(ListaElectoral lista) {
        this.lista = lista;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }
}
