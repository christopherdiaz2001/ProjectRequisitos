package votacion.modelo;

/**
 *
 * @author
 */
public class Candidato extends Modelo {
    public static enum Cargo {
        Presidente,
        Vicepresidente,
        Secretario,
        Vocal
    }
    
    private String cedula;
    private String nombres;
    private Cargo cargo;

    public Candidato(String cedula, String nombres, Cargo cargo) {
        this.cedula = cedula;
        this.nombres = nombres;
        this.cargo = cargo;
    }

    public String getCedula() {
        return cedula;
    }

    public void setCedula(String cedula) {
        this.cedula = cedula;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public Cargo getCargo() {
        return cargo;
    }

    public void setCargo(Cargo cargo) {
        this.cargo = cargo;
    }
}
