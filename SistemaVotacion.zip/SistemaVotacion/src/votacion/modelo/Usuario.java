package votacion.modelo;

/**
 *
 * @author
 */
public class Usuario extends Modelo {
    public static enum Rol {
        Admin,
        Votante
    }
    
    private String cedula;
    private String password;
    private String email;
    private String nombres;
    private Rol rol;

    public Usuario(String cedula, String password, String email, String nombres, Rol rol) {
        this.cedula = cedula;
        this.password = password;
        this.email = email;
        this.nombres = nombres;
        this.rol = rol;
    }

    public String getCedula() {
        return cedula;
    }

    public void setCedula(String cedula) {
        this.cedula = cedula;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public Rol getRol() {
        return rol;
    }

    public void setRol(Rol rol) {
        this.rol = rol;
    }
}
