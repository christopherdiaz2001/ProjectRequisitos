package votacion.modelo;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author
 */
public class ListaElectoral extends Modelo {
    private String nombre;
    private String slogan;
    private List<Candidato> candidatos = new ArrayList<>();

    public ListaElectoral(String nombre, String slogan) {
        this.nombre = nombre;
        this.slogan = slogan;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getSlogan() {
        return slogan;
    }

    public void setSlogan(String slogan) {
        this.slogan = slogan;
    }

    public List<Candidato> getCandidatos() {
        return candidatos;
    }

    public void setCandidatos(List<Candidato> candidatos) {
        this.candidatos = candidatos;
    }
}
