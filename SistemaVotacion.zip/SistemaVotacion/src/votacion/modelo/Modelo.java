package votacion.modelo;

import org.bson.types.ObjectId;

/**
 *
 * @author
 */
public abstract class Modelo {
    private ObjectId objectId;

    public ObjectId getObjectId() {
        return objectId;
    }

    public void setObjectId(ObjectId objectId) {
        this.objectId = objectId;
    }
}
