package votacion.controlador;

import votacion.vista.VentanaPrincipal;
import java.util.List;
import java.util.ArrayList;
import utils.Encriptamiento;
import votacion.dao.UsuariosDao;
import votacion.modelo.Usuario;

/**
 * Clase principal para la aplicacion, esta se encarga de:
 * - instanciar todos los controladores e inicializarlos
 * - crear la ventana principal y mostrarla
 * 
 * Esta clase es de instancia unica (SINGLETON)
 * 
 * 
 * @author
 */
public class Aplicacion {
    private static Aplicacion instancia = null;
    private Usuario usuarioActual = null;
    private List<ControladorBase> controladores = new ArrayList<>();
    private final VentanaPrincipal ventana = new VentanaPrincipal();
    
    public static Aplicacion getInstancia() {
        if (instancia == null) {
            instancia = new Aplicacion();
        }
        
        return instancia;
    }
    
    public void iniciar() {
        ControladorAutentificacion controladorAutentificacion
                = new ControladorAutentificacion(this);
        
        controladorAutentificacion.alIngresar(() -> {
            // registramos todos los controladores
            controladores.add(new ControladorPrincipal(this));
            controladores.add(new ControladorVotaciones(this));
            controladores.add(new ControladorListas(this));
            
            if (getUsuarioActual().getRol() == Usuario.Rol.Admin) {
                controladores.add(new ControladorAdministracion(this));
            }

            // inicializamos todos los controladores
            for (ControladorBase controlador : controladores) {
                controlador.inicializar();
            }

            // centramos la ventana y la mostramos
            ventana.setLocationRelativeTo(null);
            ventana.setVisible(true);
        });
        controladorAutentificacion.inicializar();
    }
    
    // getter para obtener la ventana principal de la aplicacion
    public VentanaPrincipal getVentana() {
        return ventana;
    }
    
    // metodo para obtener un controlador dado su identificador
    // cada controlador tiene un identificador gracias al metodo id()
    public ControladorBase getControlador(String id) {
        for (ControladorBase controlador : controladores) {
            if (controlador.getId().equalsIgnoreCase(id)) {
                return controlador;
            }
        }
        
        return null;
    }
    
    public void setUsuarioActual(Usuario usuario) {
        this.usuarioActual = usuario;
    }
    
    public Usuario getUsuarioActual() {
        return usuarioActual;
    }
    
    // constructor privado
    private Aplicacion() {
        crearCuentaAdministrador();
    }
    
    private void crearCuentaAdministrador() {
        UsuariosDao usuariosDao = new UsuariosDao();
        
        if (usuariosDao.totalUsuarios() == 0) {
            usuariosDao.crear(new Usuario("1447229897", Encriptamiento.encriptarPassword("goodfeeling2"), "csteyo@espe.edu.ec", "Carlos Teyo", Usuario.Rol.Admin));
            usuariosDao.crear(new Usuario("1431370392", Encriptamiento.encriptarPassword("epicphone5"), "lrpaul@espe.edu.ec", "Les Paul", Usuario.Rol.Admin));
        }
    }
}
