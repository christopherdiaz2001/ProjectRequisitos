package votacion.controlador;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

/**
 *
 * @author
 */
public class BaseDeDatos {
    private MongoClient mongoClient;
    private MongoDatabase database;
    private static BaseDeDatos instancia = null;
    
    public static BaseDeDatos getInstancia() {
        if (instancia == null) {
            instancia = new BaseDeDatos();
        }
        
        return instancia;
    }
    
    private BaseDeDatos() {
        mongoClient = MongoClients.create("mongodb://localhost:27017");
        database = mongoClient.getDatabase("sistemavotaciones");
    }
    
    public MongoCollection getColeccion(String name) {
        return database.getCollection(name);
    }
}
