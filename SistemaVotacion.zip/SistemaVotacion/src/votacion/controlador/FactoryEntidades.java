package votacion.controlador;

import java.util.List;
import utils.Encriptamiento;
import votacion.modelo.Candidato;
import votacion.modelo.ListaElectoral;
import votacion.modelo.Usuario;

/**
 *
 * @author
 */
public class FactoryEntidades implements AbstractFactoryEntidades {
    @Override
    public Candidato crearCandidato(String cedula, String nombre, Candidato.Cargo cargo) {
        Candidato candidato = new Candidato(cedula, nombre, cargo);
        return candidato;
    }

    @Override
    public ListaElectoral crearLista(String nombre, String slogan, List<Candidato> candidatos) {
        ListaElectoral lista = new ListaElectoral(nombre, slogan);
        lista.setCandidatos(candidatos);
        return lista;
    }
    
    @Override
    public Usuario crearUsuario(String cedula, String nombres, String password, String email, Usuario.Rol rol) {
        Usuario usuario = new Usuario(cedula, Encriptamiento.encriptarPassword(password), email, nombres, rol);
        return usuario;
    }
}
