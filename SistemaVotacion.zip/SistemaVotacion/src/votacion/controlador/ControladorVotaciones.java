package votacion.controlador;

import votacion.dao.ListasElectoralesDao;
import votacion.dao.VotacionesDao;
import votacion.modelo.ListaElectoral;
import votacion.modelo.MensajeEstado;
import votacion.modelo.Votacion;
import votacion.vista.VentanaPrincipal;
import votacion.vista.VistaRealizarVotacion;

/**
 *
 * @author
 */
public class ControladorVotaciones extends ControladorBase {
    private VentanaPrincipal ventana = getApp().getVentana();
    private ListasElectoralesDao listasDao = new ListasElectoralesDao();
    private VotacionesDao votacionesDao = new VotacionesDao();
    
    public ControladorVotaciones(Aplicacion app) {
        super(app);
    }
    
    @Override
    public void inicializar() {
        ventana.agregarElementoMenu(
            "Realizar votación",
            "imagenes/box-ballot.png",
            this::mostrarVistaRealizarVotacion
        );
        
        ventana.agregarSeparadorMenu(null);
    }

    @Override
    public String id() {
        return "votaciones";
    }
    
    private void mostrarVistaRealizarVotacion() {
        ventana.mostrarVista(new VistaRealizarVotacion(this));
    }

    public ListasElectoralesDao getListasDao() {
        return listasDao;
    }
    
    public VotacionesDao getVotacionesDao() {
        return votacionesDao;
    }

    public MensajeEstado realizarVotacion(ListaElectoral lista) {
        Votacion voto = new Votacion(lista, getApp().getUsuarioActual());
        votacionesDao.crear(voto);
        return MensajeEstado.ok("Voto realizado con exito");
    }

    public boolean votoRealizado() {
        return votacionesDao.votoRealizado(getApp().getUsuarioActual());
    }
}
