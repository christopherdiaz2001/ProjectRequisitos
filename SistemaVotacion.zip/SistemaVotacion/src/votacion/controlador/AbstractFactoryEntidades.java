package votacion.controlador;

import java.util.List;
import votacion.modelo.Candidato;
import votacion.modelo.ListaElectoral;
import votacion.modelo.Usuario;
import votacion.modelo.Usuario.Rol;

/**
 *
 * @author
 */
public interface AbstractFactoryEntidades {
    Candidato crearCandidato(String cedula, String nombre, Candidato.Cargo cargo);
    ListaElectoral crearLista(String nombre, String slogan, List<Candidato> candidatos);
    Usuario crearUsuario(String cedula, String nombres, String password, String email, Rol rol);
}
