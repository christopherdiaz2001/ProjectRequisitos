package votacion.controlador;

import votacion.dao.ListasElectoralesDao;
import votacion.modelo.ListaElectoral;
import votacion.modelo.MensajeEstado;
import votacion.modelo.Usuario;
import votacion.vista.VentanaPrincipal;
import votacion.vista.VistaAgregarLista;
import votacion.vista.VistaVerListas;

/**
 *
 * @author
 */
public class ControladorListas extends ControladorBase {
    private VentanaPrincipal ventana = getApp().getVentana();
    private ListasElectoralesDao listasDao = new ListasElectoralesDao();
    
    public ControladorListas(Aplicacion app) {
        super(app);
    }
    
    @Override
    public void inicializar() {
        Usuario usuario = getApp().getUsuarioActual();
        
        if (usuario.getRol() == Usuario.Rol.Admin) {
            ventana.agregarElementoMenu(
                "Agregar Lista electoral",
                "imagenes/agregar.png",
                this::mostrarVistaAgregarLista
            );
        }
        
        ventana.agregarElementoMenu(
            "Ver listas electorales",
            "imagenes/list-check.png",
            this::mostrarVistaVerListas
        );
        
        ventana.agregarSeparadorMenu(null);
    }

    @Override
    public String id() {
        return "admin";
    }
    
    private void mostrarVistaAgregarLista() {
        ventana.mostrarVista(new VistaAgregarLista(this));
    }
    
    private void mostrarVistaVerListas() {
        ventana.mostrarVista(new VistaVerListas(this));
    }

    public MensajeEstado crearLista(ListaElectoral lista) {
        if (listasDao.buscarPorCampo("nombre", lista.getNombre()) != null) {
            return MensajeEstado.error("Ya existe una lista con ese nombre");
        }
        
        listasDao.crear(lista);
        return MensajeEstado.ok("Lista creada con exito");
    }
    
    public ListasElectoralesDao getListasDao() {
        return listasDao;
    }

    public MensajeEstado eliminarLista(ListaElectoral lista) {
        listasDao.eliminar(lista);
        return MensajeEstado.ok("Lista eliminada con exito");
    }
}
