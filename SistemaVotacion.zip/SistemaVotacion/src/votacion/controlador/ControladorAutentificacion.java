package votacion.controlador;

import javax.swing.JFrame;
import votacion.dao.AutentificacionDao;
import votacion.dao.UsuariosDao;
import votacion.modelo.MensajeEstado;
import votacion.vista.VentanaIngreso;

/**
 *
 * @author
 */
public class ControladorAutentificacion extends ControladorBase {
    private UsuariosDao usuariosDao = new UsuariosDao();
    private AutentificacionDao autentificacionDao = new AutentificacionDao();
    private Runnable ingresoRetrollamada = null;
    private final VentanaIngreso ventanaIngreso = new VentanaIngreso(this);
    
    public ControladorAutentificacion(Aplicacion app) {
        super(app);
        ventanaIngreso.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ventanaIngreso.setLocationRelativeTo(null);
        ventanaIngreso.setVisible(true);
    }

    public void alIngresar(Runnable retrollamada) {
        ingresoRetrollamada = retrollamada;
    }

    public MensajeEstado ingresar(String cedula, String password) {
        MensajeEstado resultado = autentificacionDao.login(cedula, password);
        
        if (resultado.correcto()) {
            getApp().setUsuarioActual(usuariosDao.obtener(cedula));
            ventanaIngreso.setVisible(false);
            ventanaIngreso.dispose();
            ingresoRetrollamada.run();
        }
        
        return resultado;
    }

    @Override
    public void inicializar() {
        ventanaIngreso.setLocationRelativeTo(null);
        ventanaIngreso.setVisible(true);
    }

    @Override
    public String id() {
        return "autentificacion";
    }
}
