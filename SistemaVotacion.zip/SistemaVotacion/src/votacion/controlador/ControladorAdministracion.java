package votacion.controlador;

import votacion.dao.UsuariosDao;
import votacion.modelo.MensajeEstado;
import votacion.modelo.Usuario;
import votacion.vista.VentanaPrincipal;
import votacion.vista.VistaAgregarVotante;

/**
 *
 * @author
 */
public class ControladorAdministracion extends ControladorBase {
    private VentanaPrincipal ventana = getApp().getVentana();
    private UsuariosDao usuariosDao = new UsuariosDao();
    
    public ControladorAdministracion(Aplicacion app) {
        super(app);
    }
    
    @Override
    public void inicializar() {
        ventana.agregarElementoMenu(
            "Agregar votante", 
            "imagenes/user-plus.png", 
            this::mostrarVistaAgregarVotante
        );
    }

    @Override
    public String id() {
        return "admin";
    }
    
    private void mostrarVistaAgregarVotante() {
        ventana.mostrarVista(new VistaAgregarVotante(this));
    }
    
    public MensajeEstado crearUsuario(Usuario usuario) {
        
        usuariosDao.crear(usuario);
        return MensajeEstado.ok("Usuario creado con exito");
    }
}
