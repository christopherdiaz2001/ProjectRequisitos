package votacion.controlador;

import votacion.dao.ListasElectoralesDao;
import votacion.dao.VotacionesDao;
import votacion.vista.VentanaPrincipal;
import votacion.vista.VentanaPrincipal.ElementoMenu;
import votacion.vista.VistaInicio;

/**
 * Controlador principal de la aplicacion, este se encarga de manejar la vista
 * "VistaInicio"
 * 
 * @author 
 */
public class ControladorPrincipal extends ControladorBase {
    // ventana principal de la aplicacion
    private VentanaPrincipal ventana = getApp().getVentana();
    private ListasElectoralesDao listasDao = new ListasElectoralesDao();
    private VotacionesDao votacionesDao = new VotacionesDao();
    
    public ControladorPrincipal(Aplicacion app) {
        super(app);
    }
    
    public VotacionesDao getVotacionesDao() {
        return votacionesDao;
    }
    
    public ListasElectoralesDao getListasDao() {
        return listasDao;
    }
    
    @Override
    public void inicializar() {
        // agregamos al menu de la ventana principal una opcion para ver
        // la vista inicio
        ElementoMenu inicio = ventana.agregarElementoMenu(
            "Inicio", 
            "imagenes/menu-icono-inicio.png", 
            this::menuInicio
        );
        
        // seleccionamos esa opcion para mostrarla apenas se muestre
        // la ventana principal de la aplicacion
        inicio.seleccionar();
    }
    
    // identificador del controlador
    @Override
    public String id() {
        return "principal";
    }

    // mostramos la vista inicio
    private void menuInicio() {
        ventana.mostrarVista(new VistaInicio(this));
    }
}
