package votacion.dao;

import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import org.bson.Document;
import org.bson.types.ObjectId;
import votacion.controlador.BaseDeDatos;
import votacion.modelo.Usuario;

/**
 *
 * @author
 */
public class UsuariosDao {
    MongoCollection<Document> coleccionUsuarios 
            = BaseDeDatos.getInstancia().getColeccion("usuarios");
    
    public int totalUsuarios() {
        FindIterable<Document> iterable = coleccionUsuarios.find();
        return (int) coleccionUsuarios.countDocuments();
    }
    
    public ObjectId crear(Usuario usuario) {
        Document documento = new Document("_id", new ObjectId())
            .append("cedula", usuario.getCedula())
            .append("password", usuario.getPassword())
            .append("email", usuario.getEmail())
            .append("nombres", usuario.getNombres())
            .append("rol", usuario.getRol().name());
        
        coleccionUsuarios.insertOne(documento);
        return documento.getObjectId("_id");
    }
    
    public Usuario buscarPorCampo(String campo, Object valor) {
        FindIterable<Document> iterable = coleccionUsuarios.find(new Document(campo, valor));
        Document doc = iterable.first();
        
        
        if (doc == null) {
            return null;
        }
        
        Usuario usuario = new Usuario(
            doc.getString("cedula"),
            doc.getString("password"),
            doc.getString("email"),
            doc.getString("nombres"),
            Usuario.Rol.valueOf(doc.getString("rol"))
        );
        usuario.setObjectId(doc.getObjectId("_id"));
        
        return usuario;
    }

    public Usuario obtener(String cedula) {
        return buscarPorCampo("cedula", cedula);
    }
}
