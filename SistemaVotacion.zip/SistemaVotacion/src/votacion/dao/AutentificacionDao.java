package votacion.dao;

import utils.Encriptamiento;
import votacion.controlador.BaseDeDatos;
import votacion.modelo.MensajeEstado;
import votacion.modelo.Usuario;

/**
 *
 * @author
 */
public class AutentificacionDao {
    private BaseDeDatos bd = BaseDeDatos.getInstancia();
    private UsuariosDao usuariosDao = new UsuariosDao();
    
    public MensajeEstado login(String nombreUsuario, String password) {
        Usuario usuario = usuariosDao.buscarPorCampo("cedula", nombreUsuario);
        
        if (usuario == null) {
            return MensajeEstado.error("no existe un usuario con esa cedula");
        }
        
        if (!Encriptamiento.verificarPassword(usuario.getPassword(), password)) {
            return MensajeEstado.error("La contraseña no coincide");
        }
        
        return MensajeEstado.ok();
    }
}
