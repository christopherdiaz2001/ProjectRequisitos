package votacion.dao;

import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import java.util.ArrayList;
import java.util.List;
import org.bson.Document;
import org.bson.types.ObjectId;
import votacion.controlador.BaseDeDatos;
import votacion.modelo.Candidato;
import votacion.modelo.ListaElectoral;
import votacion.modelo.Usuario;
import votacion.modelo.Votacion;

/**
 *
 * @author
 */
public class VotacionesDao {
    private MongoCollection<Document> coleccion = BaseDeDatos.getInstancia().getColeccion("votaciones");
    
    public void crear(Votacion votacion) {
        ListaElectoral lista = votacion.getLista();
        Usuario usuario = votacion.getUsuario();
        
        Document documentoUsuario = new Document("_id", usuario.getObjectId())
            .append("cedula", usuario.getCedula())
            .append("password", usuario.getPassword())
            .append("email", usuario.getEmail())
            .append("nombres", usuario.getNombres())
            .append("rol", usuario.getRol().name());
        
        Document documentoLista = new Document("_id", lista.getObjectId())
            .append("nombre", lista.getNombre())
            .append("slogan", lista.getSlogan())
            .append("candidatos", lista.getCandidatos().stream().map((candidato) -> {
                return new Document("cedula", candidato.getCedula())
                    .append("nombres", candidato.getNombres())
                    .append("cargo", candidato.getCargo().name());
            }).toList());
        
        Document documento = new Document("_id", new ObjectId())
            .append("lista", documentoLista)
            .append("usuario", documentoUsuario);
        
        coleccion.insertOne(documento);
    }
    
    public List<Votacion> getVotaciones() {
        List<Votacion> votaciones = new ArrayList<>();
        FindIterable<Document> iterable = coleccion.find();
        
        for (Document documento : iterable) {
            Document documentoUsuario = documento.get("usuario", Document.class);
            Document documentoLista = documento.get("lista", Document.class);

            Usuario usuario = new Usuario(
                documentoUsuario.getString("cedula"),
                documentoUsuario.getString("password"),
                documentoUsuario.getString("email"),
                documentoUsuario.getString("nombres"),
                Usuario.Rol.valueOf(documentoUsuario.getString("rol"))
            );
            usuario.setObjectId(documentoUsuario.getObjectId("_id"));

            List<Document> candidatosDocumentos = documentoLista.getList("candidatos", Document.class);
            List<Candidato> candidatos = new ArrayList<>();

            for (Document doc : candidatosDocumentos) {
                Candidato candidato = new Candidato(
                    doc.getString("cedula"),
                    doc.getString("nombres"),
                    Candidato.Cargo.valueOf(doc.getString("cargo"))
                );
                candidato.setObjectId(doc.getObjectId("_id"));
                candidatos.add(candidato);
            }

            ListaElectoral lista = new ListaElectoral(documentoLista.getString("nombre"), documentoLista.getString("slogan"));
            lista.setCandidatos(candidatos);
            lista.setObjectId(documentoLista.getObjectId("_id"));

            Votacion votacion = new Votacion(lista, usuario);
            votacion.setObjectId(documento.getObjectId("_id"));
            votaciones.add(votacion);
        }
        
        return votaciones;
    }
    
    public boolean votoRealizado(Usuario usuario) {
        return buscarPorCampo("usuario.cedula", usuario.getCedula()) != null;
    }
    
    public Votacion buscarPorCampo(String campo, Object valor) {
        FindIterable<Document> iterable = coleccion.find(new Document(campo, valor));
        Document documento = iterable.first();
        
        if (documento == null) {
            return null;
        }
        
        Document documentoUsuario = documento.get("usuario", Document.class);
        Document documentoLista = documento.get("lista", Document.class);
        
        Usuario usuario = new Usuario(
            documentoUsuario.getString("cedula"),
            documentoUsuario.getString("password"),
            documentoUsuario.getString("email"),
            documentoUsuario.getString("nombres"),
            Usuario.Rol.valueOf(documentoUsuario.getString("rol"))
        );
        usuario.setObjectId(documentoUsuario.getObjectId("_id"));
        
        List<Document> candidatosDocumentos = documentoLista.getList("candidatos", Document.class);
        List<Candidato> candidatos = new ArrayList<>();

        for (Document doc : candidatosDocumentos) {
            Candidato candidato = new Candidato(
                doc.getString("cedula"),
                doc.getString("nombres"),
                Candidato.Cargo.valueOf(doc.getString("cargo"))
            );
            candidato.setObjectId(doc.getObjectId("_id"));
            candidatos.add(candidato);
        }

        ListaElectoral lista = new ListaElectoral(documentoLista.getString("nombre"), documentoLista.getString("slogan"));
        lista.setCandidatos(candidatos);
        lista.setObjectId(documentoLista.getObjectId("_id"));
        
        Votacion votacion = new Votacion(lista, usuario);
        votacion.setObjectId(documento.getObjectId("_id"));
        
        return votacion;
    }
}
