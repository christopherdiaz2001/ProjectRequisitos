package votacion.dao;

import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import java.util.ArrayList;
import java.util.List;
import org.bson.Document;
import org.bson.types.ObjectId;
import votacion.controlador.BaseDeDatos;
import votacion.modelo.Candidato;
import votacion.modelo.ListaElectoral;

/**
 *
 * @author
 */
public class ListasElectoralesDao {
    private MongoCollection<Document> coleccion = BaseDeDatos.getInstancia().getColeccion("listas");
    
    public ObjectId crear(ListaElectoral lista) {
        ObjectId id = new ObjectId();
        Document documento = new Document("_id", id)
            .append("nombre", lista.getNombre())
            .append("slogan", lista.getSlogan())
            .append("candidatos", lista.getCandidatos().stream().map((candidato) -> {
                return new Document("cedula", candidato.getCedula())
                    .append("nombres", candidato.getNombres())
                    .append("cargo", candidato.getCargo().name());
            }).toList());
        
        coleccion.insertOne(documento);
        return id;
    }
    
    public List<ListaElectoral> getListas() {
        List<ListaElectoral> listas = new ArrayList<>();
        FindIterable<Document> iterable = coleccion.find();
        
        for (Document documento : iterable) {
            List<Document> candidatosDocumentos = documento.getList("candidatos", Document.class);
            List<Candidato> candidatos = new ArrayList<>();
            
            for (Document doc : candidatosDocumentos) {
                Candidato candidato = new Candidato(
                    doc.getString("cedula"),
                    doc.getString("nombres"),
                    Candidato.Cargo.valueOf(doc.getString("cargo"))
                );
                candidato.setObjectId(doc.getObjectId("_id"));
                candidatos.add(candidato);
            }
            
            ListaElectoral lista = new ListaElectoral(documento.getString("nombre"), documento.getString("slogan"));
            lista.setCandidatos(candidatos);
            lista.setObjectId(documento.getObjectId("_id"));
            listas.add(lista);
        }
        
        return listas;
    }
    
    public ListaElectoral buscarPorCampo(String campo, Object valor) {
        FindIterable<Document> iterable = coleccion.find(new Document(campo, valor));
        Document documento = iterable.first();
        
        
        if (documento == null) {
            return null;
        }
        
        List<Document> candidatosDocumentos = documento.getList("candidatos", Document.class);
        List<Candidato> candidatos = new ArrayList<>();

        for (Document doc : candidatosDocumentos) {
            Candidato candidato = new Candidato(
                doc.getString("cedula"),
                doc.getString("nombres"),
                Candidato.Cargo.valueOf(doc.getString("cargo"))
            );
            candidato.setObjectId(doc.getObjectId("_id"));
            candidatos.add(candidato);
        }

        ListaElectoral lista = new ListaElectoral(documento.getString("nombre"), documento.getString("slogan"));
        lista.setCandidatos(candidatos);
        lista.setObjectId(documento.getObjectId("_id"));
        
        return lista;
    }

    public boolean existeCedulaEnCandidatos(String cedula) {
        List<ListaElectoral> listas = getListas();
        
        for (ListaElectoral lista : listas) {
            for (Candidato candidato : lista.getCandidatos()) {
                if (candidato.getCedula().equals(cedula)) {
                    return true;
                }
            }
        }
        
        return false;
    }

    public void eliminar(ListaElectoral lista) {
        coleccion.deleteOne(new Document("_id", lista.getObjectId()));
    }
}
