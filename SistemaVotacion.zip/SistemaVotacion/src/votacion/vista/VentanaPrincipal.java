package votacion.vista;

import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.Box.Filler;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.border.EmptyBorder;

/**
 *
 * @author
 */
public class VentanaPrincipal extends javax.swing.JFrame {
    private final List<ElementoMenu> menuElementos = new ArrayList<>();
    private final Color menuItemBackground = new Color(245, 245, 247);
    private final Color menuItemSeleccionadoBackground = new Color(69, 170, 242);
    private final Color menuItemHoverBackground = new Color(232, 232, 232);
    private final Color menuItemForeground = new Color(70, 87, 107);
    private final Color menuItemSeleccionadoForeground = new Color(255,255,255);
    private final Color menuItemHoverForeground = new Color(70, 87, 107);
    
    /**
     * Creates new form VentanaPrincipal
     */
    public VentanaPrincipal() {
        initComponents();
        lblLogo.setIcon(new ImageIcon(getClass().getClassLoader().getResource("imagenes/logo.png")));
        btnAcercaDe.setIcon(new ImageIcon(getClass().getClassLoader().getResource("imagenes/acercade.png")));
    }
    
    /**
     * Este metodo agrega un elemento al menu lateral de la ventana
     * recibe el texto de la opcion del menu, el nombre del icono (imagen PNG)
     * y una funcion/metodo que sera llamada cuando den click a la opcion del menu
     */
    public ElementoMenu agregarElementoMenu(String texto, String icono, Runnable accion) {
        JPanel panel = new JPanel();
        panel.setBackground(menuItemBackground);
        panel.setMaximumSize(new Dimension(2147483647, 30));
        panel.setLayout(new BoxLayout(panel, BoxLayout.LINE_AXIS));
        panel.setCursor(new Cursor(Cursor.HAND_CURSOR));

        JLabel lblIcono = new JLabel(new ImageIcon(getClass().getClassLoader().getResource(icono)));
        lblIcono.setName("icono");
            
        int lblIconoWidth = 40;
        int lblIconoHeight = 20;
        
        lblIcono.setMinimumSize(new Dimension(lblIconoWidth, lblIconoHeight));
        lblIcono.setPreferredSize(new Dimension(lblIconoWidth, lblIconoHeight));
        lblIcono.setMaximumSize(new Dimension(lblIconoWidth, lblIconoHeight));
        lblIcono.setBorder(BorderFactory.createEmptyBorder(1, 8, 0, 15));
        lblIcono.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        lblIcono.setHorizontalAlignment(JLabel.CENTER);
        
        JLabel lblTexto = new JLabel();
        lblTexto.setForeground(menuItemForeground);
        Font font = new Font("Segoe UI", 0, 13).deriveFont(lblTexto.getFont().getStyle());
        lblTexto.setFont(font);
        lblTexto.setName("texto");
        lblTexto.setText(texto);
        lblTexto.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        panel.add(lblIcono);
        panel.add(lblTexto);
        menu.add(panel);

        Filler separador = new Filler(new Dimension(0, 5), new Dimension(0, 5), new Dimension(32767, 5));
        menu.add(separador);
        
        ElementoMenu elementoMenu = new ElementoMenu(texto, accion, panel);

        panel.addMouseListener(new MouseListener() {
            @Override
            public void mouseEntered(MouseEvent e) {
                if (elementoMenu.activo) {
                    panel.setBackground(menuItemSeleccionadoBackground);
                } else {
                    panel.setBackground(menuItemHoverBackground);
                }
            }

            @Override
            public void mouseExited(MouseEvent e) {
                if (elementoMenu.activo) {
                    panel.setBackground(menuItemSeleccionadoBackground);
                } else {
                    panel.setBackground(menuItemBackground);
                }
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                desmarcarElementosMenu();
                accion.run();
                elementoMenu.activo = true;
                panel.setBackground(menuItemSeleccionadoBackground);
                lblTexto.setForeground(menuItemSeleccionadoForeground);
            }

            @Override
            public void mouseClicked(MouseEvent e) {}

            @Override
            public void mousePressed(MouseEvent e) {}
        });
            
        menuElementos.add(elementoMenu);
        
        return elementoMenu;
    }
    
    public void agregarSeparadorMenu(String titulo) {
        JSeparator separador = new JSeparator();
        separador.setBackground(new Color(236, 240, 241));
        separador.setForeground(new Color(222, 229, 231));
        separador.setPreferredSize(new Dimension(10, 10));
        separador.setMaximumSize(new Dimension(300, 10));
        
        menu.add(separador);
    }
    
    // desmarca todos las opciones del menu
    public void desmarcarElementosMenu() {
        for (ElementoMenu elemento : menuElementos) {
            JPanel panel = elemento.panel;
            JLabel lblTexto = null;
            Component[] componentes = panel.getComponents();
            
            for (int i = 0; i < componentes.length; i++) {
                Component componente = componentes[i];
                
                if (componente.getName().equalsIgnoreCase("texto")) {
                   lblTexto = (JLabel) componente;
                   break;
                }
            }
            
            elemento.activo = false;
            panel.setBackground(menuItemBackground);
            
            if (lblTexto != null) {
                lblTexto.setForeground(menuItemForeground);
            }
        }
    }
    
    public ElementoMenu getElementoMenu(String id) {
        for (ElementoMenu elemento : menuElementos) {
            if (elemento.id.equals(id)) {
                return elemento;
            }
        }
        
        return null;
    }
    
    // muestra una vista en la ventana, una vista es basicamente un JPanel
    // al mostrar una vista se reemplaza un JPanel por otro
    public void mostrarVista(JPanel vista) {
        vista.setOpaque(false);
        vista.setBorder(new EmptyBorder(10, 10, 10, 10));
        contenido.setViewportView(vista);
        contenido.getViewport().setOpaque(false);
        contenido.repaint();
        contenido.revalidate();
        repaint();
        revalidate();
        contenido.repaint();
        contenido.revalidate();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        sidebar = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        menu = new javax.swing.JPanel();
        jSeparator2 = new javax.swing.JSeparator();
        lblLogo = new javax.swing.JLabel();
        btnAcercaDe = new javax.swing.JButton();
        main = new javax.swing.JPanel();
        contenedor = new javax.swing.JPanel();
        contenido = new javax.swing.JScrollPane();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Sistema de votaciones");
        getContentPane().setLayout(new java.awt.GridBagLayout());

        sidebar.setBackground(new java.awt.Color(236, 240, 241));
        sidebar.setMaximumSize(new java.awt.Dimension(240, 2147483647));
        sidebar.setMinimumSize(new java.awt.Dimension(240, 100));
        sidebar.setPreferredSize(new java.awt.Dimension(240, 505));
        sidebar.setLayout(new java.awt.BorderLayout());

        jPanel1.setBackground(new java.awt.Color(245, 245, 247));

        jLabel1.setFont(new java.awt.Font("Segoe UI Black", 0, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(28, 89, 129));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel1.setText("   Votaciones");
        jLabel1.setAlignmentX(0.5F);
        jLabel1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        jSeparator1.setBackground(new java.awt.Color(236, 240, 241));
        jSeparator1.setForeground(new java.awt.Color(222, 229, 231));

        menu.setBackground(new java.awt.Color(245, 245, 247));
        menu.setLayout(new javax.swing.BoxLayout(menu, javax.swing.BoxLayout.Y_AXIS));

        jSeparator2.setForeground(new java.awt.Color(189, 195, 199));
        jSeparator2.setOrientation(javax.swing.SwingConstants.VERTICAL);

        btnAcercaDe.setBorder(null);
        btnAcercaDe.setBorderPainted(false);
        btnAcercaDe.setContentAreaFilled(false);
        btnAcercaDe.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnAcercaDe.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAcercaDeActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jSeparator1)
                        .addGap(20, 20, 20))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(menu, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(13, 13, 13)
                                .addComponent(lblLogo, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(btnAcercaDe, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 22, Short.MAX_VALUE)))
                .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 3, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(lblLogo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 35, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(menu, javax.swing.GroupLayout.DEFAULT_SIZE, 329, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 152, Short.MAX_VALUE)
                .addComponent(btnAcercaDe, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
            .addComponent(jSeparator2)
        );

        sidebar.add(jPanel1, java.awt.BorderLayout.CENTER);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.fill = java.awt.GridBagConstraints.VERTICAL;
        gridBagConstraints.weighty = 1.0;
        getContentPane().add(sidebar, gridBagConstraints);

        main.setBackground(new java.awt.Color(255, 255, 255));
        main.setMinimumSize(new java.awt.Dimension(100, 0));

        contenedor.setBackground(new java.awt.Color(255, 255, 255));
        contenedor.setOpaque(false);
        contenedor.setLayout(new java.awt.CardLayout());

        contenido.setBorder(null);
        contenido.setOpaque(false);
        contenedor.add(contenido, "card2");

        javax.swing.GroupLayout mainLayout = new javax.swing.GroupLayout(main);
        main.setLayout(mainLayout);
        mainLayout.setHorizontalGroup(
            mainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(mainLayout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addComponent(contenedor, javax.swing.GroupLayout.DEFAULT_SIZE, 696, Short.MAX_VALUE)
                .addGap(0, 0, 0))
        );
        mainLayout.setVerticalGroup(
            mainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(mainLayout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addComponent(contenedor, javax.swing.GroupLayout.DEFAULT_SIZE, 615, Short.MAX_VALUE)
                .addGap(0, 0, 0))
        );

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 1.0;
        getContentPane().add(main, gridBagConstraints);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnAcercaDeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAcercaDeActionPerformed
        DialogoAcercaDe dialogo = new DialogoAcercaDe(this, true);
        dialogo.setLocationRelativeTo(null);
        dialogo.setVisible(true);
    }//GEN-LAST:event_btnAcercaDeActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAcercaDe;
    private javax.swing.JPanel contenedor;
    private javax.swing.JScrollPane contenido;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JLabel lblLogo;
    private javax.swing.JPanel main;
    private javax.swing.JPanel menu;
    private javax.swing.JPanel sidebar;
    // End of variables declaration//GEN-END:variables
    
    public class ElementoMenu {
        public String id;
        public String texto;
        public Runnable accion;
        public JPanel panel;
        public boolean activo = false;
        
        public ElementoMenu(String texto, Runnable accion, JPanel panel) {
            this.texto = texto;
            this.accion = accion;
            this.panel = panel;
        }
        
        public ElementoMenu(String id, String texto, Runnable accion, JPanel panel) {
            this.id = id;
            this.texto = texto;
            this.accion = accion;
            this.panel = panel;
        }
        
        public void seleccionar() {
            desmarcarElementosMenu();
            accion.run();
            activo = true;
            panel.setBackground(new Color(69, 170, 242));
            
            for (int i = 0; i < panel.getComponents().length; i++) {
                if (panel.getComponents()[i].getName().equalsIgnoreCase("texto")) {
                    panel.getComponents()[i].setForeground(Color.WHITE);
                    break;
                }
            }
        }
    }
}
