package votacion.vista;

import votacion.controlador.Aplicacion;
import com.formdev.flatlaf.FlatLightLaf;

/**
 *
 * @author
 */
public class Main {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // definimos el tema de interfaz con la libreria FlatLightLaf, lo que
        // nos proporciona un diseño mas moderno.
        FlatLightLaf.setup();
        
        // obtenemos la instancia de la clase aplicacion
        Aplicacion app = Aplicacion.getInstancia();
        
        // iniciamos la aplicacion
        app.iniciar();
    }
}
